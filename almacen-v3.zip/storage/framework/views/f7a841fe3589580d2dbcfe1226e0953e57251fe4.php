

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalle del producto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <div class="card">
         <div class="card-body">
            <h1><?php echo e($producto->pro_nombre); ?></h1>
          
               <li><?php echo e($producto->pro_precio); ?></li>
               <li><?php echo e($producto->pro_cantidad); ?></li>
               <li><?php echo e($producto->kit->kit_nombre); ?></li>
               
         </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/productos/show.blade.php ENDPATH**/ ?>