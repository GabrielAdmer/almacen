

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
  <div class="d-flex  justify-content-between" >
       <h1>Listado de Almacenes</h1>
      <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.categorias.create')): ?>
               <a class="btn btn btn-dark" href="<?php echo e(route("admin.categorias.create")); ?>">Agregar Categoria</a>
           <?php endif; ?>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session("info")): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session("info")); ?></strong>
    </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                            <td><?php echo e($categoria->id); ?></td>
                            <td><?php echo e($categoria->cat_nombre); ?></td>
                           <td width="10px">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.categorias.show')): ?>
                                 <a class="btn btn-sm btn-info" href="<?php echo e(route("admin.categorias.show",$categoria)); ?>">
                                    Ver
                                  </a>
                              <?php endif; ?>
                           </td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.categorias.edit')): ?>
                                     <a class="btn btn-sm btn-success" href="<?php echo e(route("admin.categorias.edit",$categoria)); ?>">
                                       Editar
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td width="10px">
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.categorias.destroy')): ?>
                                   <form action="<?php echo e(route("admin.categorias.destroy",$categoria)); ?>" method="POST" >
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field("delete"); ?>
                                       <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Desea eliminar ? ...')" >Eliminar</button>
                                    </form>
                               <?php endif; ?>
                            </td>
                       </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

           
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/categorias/index.blade.php ENDPATH**/ ?>