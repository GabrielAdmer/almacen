

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear Empleados</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card" >
        <div class="card-body">
            <?php echo Form::open(['route'=> 'admin.empleados.store']); ?>


                <?php echo $__env->make('admin.empleados.partials.forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="form-group">
                    <?php echo e(Form::submit("Crear empleados",["class" => "btn btn-primary"])); ?>

                </div>
               

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/empleados/create.blade.php ENDPATH**/ ?>