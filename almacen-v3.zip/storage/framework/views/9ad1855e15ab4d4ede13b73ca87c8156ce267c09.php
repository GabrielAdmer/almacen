

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('css'); ?>
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
       <div class="d-flex  justify-content-between" >
       <h1>Listado de Prestamos</h1>
      <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.prestamos.create')): ?>
               <a class="btn btn btn-dark" href="<?php echo e(route("admin.prestamos.create")); ?>">Agregar Prestamos</a>
           <?php endif; ?>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  

<?php if(session("info")): ?>
<div class="alert alert-success">
    <strong><?php echo e(session("info")); ?></strong>
</div>
<?php endif; ?>

<div class="card">
     
    <div class="card-body">
        <div id="buttons" >

        </div>

        <table class="table" id="example">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre Empleado</th>
                    <th>Estado</th>
                    <th>Creado</th>
                    <th>Actulizado</th>
                    <th>Ver</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody>    

               <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($prestamo->id); ?></td>
                        <td><?php echo e($prestamo->empleado->emp_nombre); ?></td>
                        <td><?php echo e($prestamo->pre_estatus); ?></td>
                        <td><?php echo e($prestamo->created_at); ?></td>
                        <td><?php echo e($prestamo->updated_at); ?></td>
                        <td width="10px">
                            <a class="btn btn-sm btn-info" href="<?php echo e(route("admin.prestamos.show",$prestamo->id)); ?>">
                            Show
                            </a>
                        </td>
                        <td width="10px">
                            <a class="btn btn-sm btn-warning" href="<?php echo e(route("admin.prestamos.edit",$prestamo->id)); ?>">
                            Editar
                            </a>
                        </td>
                        <td width="10px">
                            <form action="<?php echo e(route("admin.prestamos.destroy",$prestamo)); ?>" method="POST" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("delete"); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Desea eliminar ? ...')" >Eliminar</button>
                            </form>
                        </td>
                    </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

       
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
   <script src="https://code.jquery.com/jquery}-3.5.1.js" defer ></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js" defer ></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js" defer ></script> 

   

    <script>
            $(document).ready(function() {
                $('#example').DataTable({
                    "language": {
                                "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
                                },
                    responsive:"true",

                });
                
             } );
    </script>
<?php $__env->stopSection(); ?>


 

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/prestamos/index.blade.php ENDPATH**/ ?>