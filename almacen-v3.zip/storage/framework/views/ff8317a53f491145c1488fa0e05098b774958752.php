


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
   <div class="d-flex  justify-content-between" >
       <h1>Listado de Proyectos</h1>
      <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.proyectos.create')): ?>
               <a class="btn btn btn-dark" href="<?php echo e(route("admin.proyectos.create")); ?>">Agregar Proyectos</a>
           <?php endif; ?>
      </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session("info")): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session("info")); ?></strong>
    </div>
    <?php endif; ?>

    <div class="card">
         
        <div class="card-body">
            

            <table class="table" id="example">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Ubicacion</th>
                        <th>status</th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php for($i = 0; $i < count($proyectos) ; $i++): ?>
                        <tr>
                            <td><?php echo e($proyectos[$i]->id); ?></td>
                            <td><?php echo e($proyectos[$i]->proy_nombre); ?></td>
                            <td><?php echo e($proyectos[$i]->proy_ubicacion); ?></td>
                            <td>
                                <?php if($proyectos[$i]->proy_estatus === "1"): ?>
                                    En proceso
                                <?php else: ?>
                                    Terminado
                                <?php endif; ?> 
                            </td>
                            <td width="10px">
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.proyectos.show")): ?>
                                  <a class="btn btn-sm btn-info" href="<?php echo e(route("admin.proyectos.show",$proyectos[$i]->id)); ?>">
                                    Show
                                 </a>
                              <?php endif; ?>
                            </td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.proyectos.edit")): ?>
                                   <a class="btn btn-sm btn-warning" href="<?php echo e(route("admin.proyectos.edit",$proyectos[$i]->id)); ?>">
                                Editar
                                </a>
                                <?php endif; ?>
                            </td>
                            <td width="10px">
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.proyectos.destroy")): ?>
                                   <form action="<?php echo e(route("admin.proyectos.destroy",$proyectos[$i]->id)); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Desea eliminar ? ...')" >Eliminar</button>
                                </form>
                               <?php endif; ?>
                            </td>
                        </tr>

                     
                    <?php endfor; ?>

                </tbody>
            </table>

           
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

    <script src="https://code.jquery.com/jquery}-3.5.1.js" defer ></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js" defer ></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js" defer ></script>

    <script>
            $(document).ready(function() {
                $('#example').DataTable({
                    "language": {
                                "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
                                }
                });
                
             } );
    </script>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/proyectos/index.blade.php ENDPATH**/ ?>