

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
   <div class="d-flex  justify-content-between" >
       <h1>Listado de Empleados</h1>
      <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.empleados.create')): ?>
              <a class="btn btn btn-dark" href="<?php echo e(route("admin.empleados.create")); ?>">Agregar Empleado</a>
           <?php endif; ?>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    


  <?php if(session("info")): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session("info")); ?></strong>
    </div>
    <?php endif; ?>

    <div class="card">
         
        <div class="card-body">
    
            <table class="table" id="example">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Apellido</th>
                        <th>Lugar</th>
                        <th span="3"></th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php for($i = 0; $i < count($empleados) ; $i++): ?>
                        <tr>
                            <td><?php echo e($empleados[$i]->id); ?></td>
                            <td><?php echo e($empleados[$i]->emp_nombre); ?></td>
                            <td><?php echo e($empleados[$i]->emp_app_paterno); ?></td>
                            <td><?php echo e($empleados[$i]->emp_app_materno); ?></td>
                            <td><?php echo e($empleados[$i]->emp_lugar); ?></td>
                            <td width="10px">
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.empleados.show")): ?>
                                     <a class="btn btn-sm btn-info" href="<?php echo e(route("admin.empleados.show",$empleados[$i]->id)); ?>">
                                       Ver..
                                    </a>
                               <?php endif; ?>
                            </td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.empleados.edit")): ?>
                                    <a class="btn btn-sm btn-success" href="<?php echo e(route("admin.empleados.edit",$empleados[$i]->id)); ?>">
                                       Editar
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td width="10px">
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.empleados.destroy")): ?>
                                    <form action="<?php echo e(route("admin.empleados.destroy",$empleados[$i]->id)); ?>" method="POST" >
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field("delete"); ?>
                                       <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Desea eliminar ? ...')" >Eliminar</button>
                                    </form>
                               <?php endif; ?>
                            </td>
                        </tr>

                     
                    <?php endfor; ?>

                </tbody>
            </table>

           
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/empleados/index.blade.php ENDPATH**/ ?>