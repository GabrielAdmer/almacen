<div class="form-group">

    <?php echo e(Form::label("pro_nombre","Nombre")); ?>

    <?php echo e(Form::text("pro_nombre",null,["class" => "form-control","placeholder"=>"Ingrese el nombre de la categoria"])); ?>


    <?php $__errorArgs = ['pro_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label("pro_precio","Precio")); ?>

    <?php echo e(Form::text("pro_precio",null,["class" => "form-control","placeholder"=>"Ingrese la cantidad de pieazas que tiene el kit"])); ?>


    <?php $__errorArgs = ['pro_precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label("pro_cantidad","Cantidad de Pieazas")); ?>

    <?php echo e(Form::number("pro_cantidad",null,["class" => "form-control","placeholder"=>"Ingrese la cantidad de pieazas que tiene el kit"])); ?>


    <?php $__errorArgs = ['pro_cantidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">
    <p>Estado : </p>
    
    <label>
        <?php echo e(Form::radio('pro_estatus',0,true)); ?>

        No hablitado
    </label>
    <label>
        <?php echo e(Form::radio('pro_estatus',1,false)); ?>

        Habilitado
    </label>
</div>

<div class="form-group">
    <p>Protocolo de Prueba : </p>
    
    <label>
        <?php echo e(Form::radio('pro_protocolo_prueba',0,true)); ?>

        Tiene
    </label>
    <label>
        <?php echo e(Form::radio('pro_protocolo_prueba',1,false)); ?>

        No tiene
    </label>
</div>

<div class="form-group">

    <?php echo e(Form::label("almacen_id","Almacen")); ?>

    <?php echo e(Form::select("almacen_id",$almacenes,null,["class"=>"form-control"])); ?>


</div>

<div class="form-group">

    <?php echo e(Form::label("categoria_id","Categoria")); ?>

    <?php echo e(Form::select("categoria_id",$categorias,null,["class"=>"form-control"])); ?>


</div>

<div class="form-group">

    <?php echo e(Form::label("kit_id","Kit")); ?>

    <?php echo e(Form::select("kit_id",$kits,null,["class"=>"form-control"])); ?>


</div>

<div class="form-group">

    <?php echo e(Form::label("proveedor_id","Proveedores")); ?>

    <?php echo e(Form::select("proveedor_id",$proveedores,null,["class"=>"form-control"])); ?>


</div>

<div class="form-group">
    <?php echo e(Form::label('pro_descripcion','Descripcion:')); ?>

    <?php echo e(Form::textarea('pro_descripcion',null, ['class'=> 'form-control'])); ?>


    <?php $__errorArgs = ['pro_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger" ><?php echo e($message); ?></span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/productos/partials/forms.blade.php ENDPATH**/ ?>