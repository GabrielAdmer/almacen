

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear Role</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card" >
        <div class="card-body">
            <?php echo Form::open(['route'=> 'admin.roles.store']); ?>


                <div class="form-group" >
                    <?php echo e(Form::label('name','Nombre')); ?>

                    <?php echo e(Form::text('name',null,['class' => 'form-control',"placeholder"=>"ingrese el nombre" ])); ?>


                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger">
                            <?php echo e($message); ?>

                        </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <h2 class="h3" >Lista de permiso</h2>
                <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <label>
                            <?php echo e(Form::checkbox('permissions[]',$permiso->id,null,['class'=>'mr-1'])); ?>

                            <?php echo e($permiso->description); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="form-group">
                    <?php echo e(Form::submit("Crear role",["class" => "btn btn-primary"])); ?>

                </div>
               

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>