

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <div class="card">
         <div class="card-body">
            <h1><?php echo e($proveedor->prov_nombre); ?></h1>
            <table class="table">
               <thead>
                  <tr>
                     <td>Nombre Producto</td>
                     <td>Precio</td>
                  </tr>
               </thead>
               <tbody>
                  <?php $__currentLoopData = $proveedor->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                           <td>
                              <?php echo e($producto->pro_nombre); ?>

                           </td>
                             <td>
                              <?php echo e($producto->pro_precio); ?>

                           </td>
                        </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/proveedores/show.blade.php ENDPATH**/ ?>