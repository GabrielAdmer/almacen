

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Crear Prestamo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
     <div class="card" >
        <div class="card-body">
            <?php echo Form::open(['route'=> 'admin.prestamos.store']); ?>


               

<?php echo e(Form::hidden('user_id',auth()->user()->id)); ?>


<div class="row">
    
    <div class="col-md-6">
        <div class="form-group">

            <?php echo e(Form::label("empleado_id","Empleado *:")); ?>

            <?php echo e(Form::select("empleado_id",$empleados,null,["class"=>"form-control"])); ?>


        </div>
    </div>

    

       <div class="col-md-6">
         <div class="form-group">
            <?php echo e(Form::label('producto_id', 'Producto')); ?>

            <?php echo e(Form::select('productos[]', $productos, null, 
            ['class' => 'form-control', 'required' => 'required','placeholder' => 'Productos...'])); ?>

        </div>
    </div>

    <div class="col-md-6">
         <div class="form-group">
            <?php echo e(Form::label('producto_id', 'Producto')); ?>

            <?php echo e(Form::select('productos[]', $productos, null, 
            ['class' => 'form-control', 'placeholder' => 'Productos...'])); ?>

        </div>
    </div>

   <div class="col-md-6" >
      <?php echo e(Form::label('producto_id', 'Producto')); ?>

         <?php echo e(Form::select('productos[]', $productos , null, ['placeholder' => 'Productos...','class'=> 'form-control'])); ?>

   </div>

 

    
    <div class="col-md-6">
         <div class="form-group">
            <?php echo e(Form::label('proy_id', 'Proyectos')); ?>

            <?php echo e(Form::select('proyecto_id', $proyectos, null, 
            ['class' => 'form-control'])); ?>

            
        </div>
    </div>


    

    <div class="col-md-6">
        <div class="form-group">
            <p>Estado de prestamo * : </p>
            
            <label>
                <?php echo e(Form::radio('pre_estado_prestamo',"buen estado",true)); ?>

                buen estado
            </label>
            <label>
                <?php echo e(Form::radio('pre_estado_prestamo',"regular",false)); ?>

                regular
            </label>
            <label>
                <?php echo e(Form::radio('pre_estado_prestamo',"mal-estado",false)); ?>

                mal estado
            </label>
        </div>

    </div>
    

   <div class="col-md-6">
       
        <p>Estado de devolucion : </p>
        
        <label>
            <?php echo e(Form::radio('pre_estado_devolucion',"buen estado",false)); ?>

            buen estado
        </label>
        <label>
            <?php echo e(Form::radio('pre_estado_devolucion',"regular",false)); ?>

            regular
        </label>
        <label>
            <?php echo e(Form::radio('pre_estado_devolucion',"mal-estado",false)); ?>

            mal estado
        </label>

   </div>

    

    <div class="col-md-6">
        <div class="form-group">
            <p>Estado de Prestamo : </p>
            
            <label>
                <?php echo e(Form::radio('pre_estatus',"devuelto",true)); ?>

                devuelto
            </label>
            <label>
                <?php echo e(Form::radio('pre_estatus',"prestamo",false)); ?>

                prestamo
            </label>
        </div>
    </div>

    

    <div class="col-md-6">
        <div class="form-group">
            <?php echo e(Form::label('pre_description_prestamo','Descripcion del prestamo *: ')); ?>

            <?php echo e(Form::textarea('pre_description_prestamo',null, ['class'=> 'form-control','required' => 'required'])); ?>


            <?php $__errorArgs = ['pre_description_prestamo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger" ><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    
    <div class="col-md-6">
        
            <?php echo e(Form::label('pre_description_devolucion','Descripcion de la devolucion:')); ?>

            <?php echo e(Form::textarea('pre_description_devolucion',null, ['class'=> 'form-control'])); ?>


        <?php $__errorArgs = ['pre_description_devolucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger" ><?php echo e($message); ?></span>
         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


</div>



      
                <div class="form-group">
                    <?php echo e(Form::submit("Generar Prestamo",["class" => "btn btn-primary"])); ?>

                </div>
               

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/prestamos/create.blade.php ENDPATH**/ ?>