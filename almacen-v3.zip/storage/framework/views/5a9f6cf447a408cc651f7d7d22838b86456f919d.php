

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Detalle del prestamo</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
       <div class="card-body">
          <p><strong>Estado del prestamo: </strong><?php echo e($prestamo->pre_estado_prestamo); ?></p>
          <p><strong>Estado del devolucion: </strong><?php echo e($prestamo->pre_estado_devolucion); ?></p>
          <p><strong>Descripcion del prestamo:</strong> <?php echo e($prestamo->pre_description_prestamo); ?></p>
          <p><strong>Descripcion devolucion:</strong> <?php echo e($prestamo->pre_description_devolucion); ?></p>
          <p><strong>Estado:</strong> <?php echo e($prestamo->pre_estatus); ?></p>
          <p><strong>Empleado: </strong><?php echo e($prestamo->empleado->emp_nombre); ?></p>
          <p><strong>Proyecto: </strong><?php echo e($prestamo->proyecto->proy_nombre); ?></p>
          <p><strong>Creado:</strong> <?php echo e(($prestamo->created_at)); ?></p>
          <p><strong>Devuelto:</strong> <?php echo e(($prestamo->updated_at)); ?></p>
          <p><strong>Producto:</strong> <?php echo e(count($prestamo->productos)); ?></p>

         <ul>
            <?php $__currentLoopData = $prestamo->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li> <?php echo e($item->pro_nombre); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>

       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/prestamos/show.blade.php ENDPATH**/ ?>