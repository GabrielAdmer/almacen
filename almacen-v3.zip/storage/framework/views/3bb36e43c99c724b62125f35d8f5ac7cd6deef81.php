<div class="form-group">

    <?php echo e(Form::label("emp_nombre","Nombre Empleado")); ?>

    <?php echo e(Form::text("emp_nombre",null,["class" => "form-control","placeholder"=>"Ingrese el nombre del empleado"])); ?>


    <?php $__errorArgs = ['emp_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


</div>

<div class="form-group">

    <?php echo e(Form::label("emp_app_paterno","Apellido Paterno")); ?>

    <?php echo e(Form::text("emp_app_paterno",null,["class" => "form-control","placeholder"=>"Ingrese su apellido paterno"])); ?>


    <?php $__errorArgs = ['emp_app_paterno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label("emp_app_materno","Apellido Paterno")); ?>

    <?php echo e(Form::text("emp_app_materno",null,["class" => "form-control","placeholder"=>"Ingrese su apellido materno"])); ?>


    <?php $__errorArgs = ['emp_app_materno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-group">

    <?php echo e(Form::label("emp_direccion","Direccion")); ?>

    <?php echo e(Form::text("emp_direccion",null,["class" => "form-control","placeholder"=>"Dirección del empleado"])); ?>


    <?php $__errorArgs = ['emp_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">

    <?php echo e(Form::label("emp_lugar","Lugar")); ?>

    <?php echo e(Form::text("emp_lugar",null,["class" => "form-control","placeholder"=>"Ingrese su lugar de procedencia"])); ?>


    <?php $__errorArgs = ['emp_lugar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger" ><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">
    <p>Estado : </p>
    
    <label>
        <?php echo e(Form::radio('emp_estatus',0,true)); ?>

        Activo
    </label>
    <label>
        <?php echo e(Form::radio('emp_estatus',1,false)); ?>

        Inactivo
    </label>
</div>
<?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/empleados/partials/forms.blade.php ENDPATH**/ ?>