


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
     <div class="d-flex  justify-content-between" >
       <h1>Listado de Productos</h1>
      <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.productos.create')): ?>
               <a class="btn btn btn-dark" href="<?php echo e(route("admin.productos.create")); ?>">Agregar Productos</a>
           <?php endif; ?>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session("info")): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session("info")); ?></strong>
    </div>
    <?php endif; ?>

    <div class="card">

        <div class="card-body">             

            <table class="table" id="example">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>kit</th>
                        <th>almacen</th>
                        <th>categoria</th>
                        <th>Estatus</th>
                        <th>Ver</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>

                     <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td> <?php echo e($producto->id); ?></td>
                            <td> <?php echo e($producto->pro_nombre); ?></td>
                            <td> <?php echo e($producto->kit->kit_nombre); ?></td>
                            <td> <?php echo e($producto->almacen->alm_nombre); ?></td>
                            <td> <?php echo e($producto->categoria->cat_nombre); ?></td>
                            <td>
                               <?php if($producto->pro_estatus === '0'): ?>
                                 <?php echo e("si"); ?>

                                 <?php else: ?>
                                 <?php echo e("no"); ?>

                               <?php endif; ?>
                            </td>
                            <td width="10px">
                               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.productos.show")): ?>
                                    <a class="btn btn-sm btn-info" href="<?php echo e(route("admin.productos.show",$producto)); ?>">
                                       Show
                                    </a>
                               <?php endif; ?>
                            </td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.productos.edit")): ?>
                                   <a class="btn btn-sm btn-warning" href="<?php echo e(route("admin.productos.edit",$producto)); ?>">
                                    Editar
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td width="10px">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.productos.destroy")): ?>
                                    <form action="<?php echo e(route("admin.productos.destroy",$producto )); ?>" method="POST" >
                                       <?php echo csrf_field(); ?>
                                       <?php echo method_field("delete"); ?>
                                       <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Desea eliminar ? ...')" >Eliminar</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                         </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

           
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

    <script src="https://code.jquery.com/jquery}-3.5.1.js" defer ></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js" defer ></script>
    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js" defer ></script>

    <script>
            $(document).ready(function() {
                $('#example').DataTable({
                    "language": {
                                "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/Spanish.json"
                                }
                });
                
             } );
    </script>
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/productos/index.blade.php ENDPATH**/ ?>