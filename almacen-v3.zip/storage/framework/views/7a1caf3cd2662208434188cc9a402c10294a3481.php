

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex  justify-content-between" >
       <h1>Listado de Kits</h1>
      <div>
            <a class="btn btn-dark" href="<?php echo e(route('admin.kits.create')); ?>" >Crear Kit</a>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session("info")): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session("info")); ?></strong>
    </div>
    <?php endif; ?>
    
   <div class="card">
      <div class="card-body">
         <table class="table" >
            <thead>
               <tr> 
                  <td>Id</td>
                  <td>Nombre</td>
                  <td>Cantidad Piezas</td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
            </thead>

            <tbody>
               <?php $__currentLoopData = $kits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                     <td><?php echo e($kit->id); ?></td>
                     <td><?php echo e($kit->kit_nombre); ?></td>
                     <td><?php echo e($kit->kit_cantidad_piezas); ?></td>
                     <td width="10px"> 
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.kits.show')): ?>
                           <a class="btn btn-info btn-sm" href="<?php echo e(route('admin.kits.show',$kit)); ?>">Ver</a> 
                        <?php endif; ?>
                     </td>
                     <td width="10px">
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.kits.edit')): ?>
                              <a class="btn btn-success btn-sm" href="<?php echo e(route('admin.kits.edit',$kit)); ?>">Editar</a>
                          <?php endif; ?> 
                     </td>


                      <td width="10px"> 
                          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("admin.kits.destroy")): ?>
                              <form action="<?php echo e(route("admin.kits.destroy",$kit)); ?>" method="POST" >
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field("delete"); ?>
                                 <input type="submit" value="Eliminar" class="btn btn-sm btn-danger"
                                          onclick="return confirm('Desaea eliminar ? ..')"
                                 >
                              </form>
                          <?php endif; ?>
                     </td>

                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            
         </table>

         <?php echo e($kits->links("pagination::bootstrap-4")); ?>


      </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\02.-Platzi\almacen-v3\resources\views/admin/kit/index.blade.php ENDPATH**/ ?>