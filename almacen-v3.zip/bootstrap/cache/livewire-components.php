<?php return array (
  'admin.user.index' => 'App\\Http\\Livewire\\Admin\\User\\Index',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);