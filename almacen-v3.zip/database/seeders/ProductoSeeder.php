<?php

namespace Database\Seeders;


use Illuminate\Database\Seeder;

class ProductoSeeder extends Seeder
{
   /**
    * Run the database seeds.
    *
    * @return void
    */
   public function run()
   {
      // $productos = Producto::factory(20)->create();

      // foreach ($productos as $producto) {
      //    $producto->proveedores()->attach([
      //       rand(1, 2),
      //       rand(3, 4)
      //    ]);
      // }
   }
}
